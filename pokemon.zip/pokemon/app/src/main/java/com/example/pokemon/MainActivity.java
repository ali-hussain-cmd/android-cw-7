package com.example.pokemon;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ArrayList<pokemon>pokeball =new ArrayList<>();

        pokemon no1 = new pokemon("Bulbasaur",R.drawable.bulbausaur,49,56,250);
        pokemon no2 = new pokemon("Ivysaur",R.drawable.ivysaur,55,36,330);
        pokemon no3 = new pokemon("Venusaur",R.drawable.venusaur,45,65,360);

        pokeball.add(no1);
        pokeball.add(no2);
        pokeball.add(no3);
        RecyclerView rv = findViewById(R.id.recyclerview);



    }
}